/*
 * Dis how ballers do...
 */

package com.mijitr.gpu;

/**
 *
 * @author MijitR
 */
public class NBodyGPU {

}
