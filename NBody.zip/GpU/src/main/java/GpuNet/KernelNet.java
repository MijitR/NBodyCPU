/*
 * Dis how ballers do...
 */

package GpuNet;

/**
 *
 * @author MijitR
 */
public class KernelNet {

    
        
}
